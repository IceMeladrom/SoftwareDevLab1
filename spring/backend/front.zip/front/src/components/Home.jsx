import React from 'react';

class Home extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="mt-5 me-auto">
                <h2>RPO Art Frontend</h2>
            </div>
        );
    }
}

export default Home;